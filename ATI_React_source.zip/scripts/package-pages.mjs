import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const dist = path.join(root, 'docs');
const publish = path.join(root, 'publish');
function asset(name) {
  if (/^(https?:|data:|\/\/)/i.test(name)) throw new Error('Expected a local asset');
  const file = path.resolve(dist, name);
  if (!file.startsWith(dist + path.sep)) throw new Error('Invalid asset path');
  return fs.readFileSync(file, 'utf8');
}
let html = fs.readFileSync(path.join(dist, 'index.html'), 'utf8');
let scripts = 0;
let styles = 0;
html = html.replace(/<script\b[^>]*\bsrc="([^"]+)"[^>]*>\s*<\/script>/g, (_, name) => {
  scripts++;
  return '<script type="module">' + asset(name).replace(/<\/script/gi, '<\\/script') + '</script>';
});
html = html.replace(/<link\b[^>]*\bhref="([^"]+\.css)"[^>]*>/g, (_, name) => {
  styles++;
  return '<style>' + asset(name).replace(/<\/style/gi, '<\\/style') + '</style>';
});
if (scripts !== 1 || styles !== 1) throw new Error('Unexpected Vite output');
fs.mkdirSync(publish, { recursive: true });
fs.writeFileSync(path.join(publish, 'index.html'), html);
console.log('Self-contained React site: publish/index.html');
