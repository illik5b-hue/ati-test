import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const root = fileURLToPath(new URL('../', import.meta.url));
const publicDir = path.join(root, 'public');
const report = path.join(publicDir, 'ATI_Primer_Pravovogo_Analiza.pdf');
if (!fs.existsSync(report)) execFileSync('python', [path.join(root, 'scripts/build-report.py')], { stdio: 'inherit' });
if ([1, 2, 3, 4].some(page => !fs.existsSync(path.join(publicDir, `report-page-${page}.jpg`)))) {
  execFileSync('pdftoppm', ['-jpeg', '-r', '96', '-scale-to-x', '794', '-scale-to-y', '1123', report, path.join(publicDir, 'report-page')], { stdio: 'inherit' });
}
