import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';
import { SITE_BASE_PATH, SITE_URL, business } from '../src/site-config.js';

const root = fileURLToPath(new URL('../', import.meta.url));
const dist = path.join(root, 'docs');
const publish = path.join(root, 'publish');
const buildDir = path.join(root, '.build');
fs.mkdirSync(buildDir, { recursive: true });
await build({ entryPoints: [path.join(root, 'scripts/render-pages.jsx')], outfile: path.join(buildDir, 'render-pages.mjs'), bundle: true, platform: 'node', format: 'esm', packages: 'external' });
const { renderPage, pageMeta } = await import(path.join(buildDir, 'render-pages.mjs'));
const asset = (name) => {
  const relative = name.startsWith(SITE_BASE_PATH + '/') ? name.slice(SITE_BASE_PATH.length + 1) : name.replace(/^\//, '');
  const file = path.resolve(dist, relative);
  if (!file.startsWith(dist + path.sep)) throw new Error('Invalid asset path');
  return fs.readFileSync(file, 'utf8');
};
const escapeHtml = text => text.replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;');
let template = fs.readFileSync(path.join(dist, 'index.html'), 'utf8');
let scripts = 0, styles = 0;
template = template.replace(/<script\b[^>]*\bsrc="([^"]+)"[^>]*>\s*<\/script>/g, (_, name) => { scripts++; return '<script type="module">' + asset(name).replace(/<\/script/gi, '<\\/script') + '</script>'; });
template = template.replace(/<link\b[^>]*\bhref="([^"]+\.css)"[^>]*>/g, (_, name) => { styles++; return '<style>' + asset(name).replace(/<\/style/gi, '<\\/style') + '</style>'; });
if (scripts !== 1 || styles !== 1) throw new Error('Unexpected Vite output');
fs.rmSync(publish, { recursive: true, force: true });
fs.mkdirSync(publish, { recursive: true });
for (const name of fs.readdirSync(path.join(root, 'public'))) fs.copyFileSync(path.join(root, 'public', name), path.join(publish, name));
const marketingPages = ['/', '/services.html', '/analysis.html', '/recovery.html'];
for (const pathname of [...Object.keys(pageMeta), '/404.html']) {
  const meta = pageMeta[pathname] || { title: 'Страница не найдена — АТИ', description: 'Запрошенная страница не найдена.' };
  const canonical = SITE_URL + (pathname === '/' ? '' : pathname.slice(1));
  const noindex = pathname === '/404.html' || (!business.privacyApproved && ['/privacy.html', '/consent.html'].includes(pathname));
  const extra = `<link rel="canonical" href="${canonical}"/><meta name="robots" content="${noindex ? 'noindex, follow' : 'index, follow'}"/><meta property="og:locale" content="ru_RU"/><meta property="og:type" content="website"/><meta property="og:title" content="${escapeHtml(meta.title)}"/><meta property="og:description" content="${escapeHtml(meta.description)}"/><meta property="og:url" content="${canonical}"/><meta property="og:site_name" content="АТИ"/><link rel="icon" type="image/svg+xml" href="${SITE_BASE_PATH}/favicon.svg"/>`;
  let html = template.replace(/<title>[\s\S]*?<\/title>/, `<title>${escapeHtml(meta.title)}</title>`).replace(/<meta name="description"[^>]*>/, `<meta name="description" content="${escapeHtml(meta.description)}"/>`).replace('</head>', extra + '</head>').replace('<div id="root"></div>', `<div id="root">${renderPage(pathname)}</div>`);
  if (pathname === '/') html = html.replace('</head>', `<script type="application/ld+json">${JSON.stringify({ '@context': 'https://schema.org', '@type': 'WebSite', name: 'АТИ', url: SITE_URL, inLanguage: 'ru' })}</script></head>`);
  fs.writeFileSync(path.join(publish, pathname === '/' ? 'index.html' : pathname.slice(1)), html);
}
fs.writeFileSync(path.join(publish, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${marketingPages.map(p => `<url><loc>${SITE_URL}${p === '/' ? '' : p.slice(1)}</loc></url>`).join('')}</urlset>\n`);
fs.writeFileSync(path.join(publish, 'README.md'), fs.readFileSync(path.join(root, 'README.md')));
console.log('Published pages prepared:', Object.keys(pageMeta).length + 1);
