import React from 'react';
import { renderToString } from 'react-dom/server';
import { StaticRouter } from 'react-router-dom/server.js';
import App from '../src/App.jsx';
import { SITE_BASE_PATH, pageMeta } from '../src/site-config.js';
export { pageMeta };
export function renderPage(pathname) {
  return renderToString(<StaticRouter basename={SITE_BASE_PATH} location={`${SITE_BASE_PATH}${pathname}`}><App /></StaticRouter>);
}
