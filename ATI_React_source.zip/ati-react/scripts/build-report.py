"""Build the clearly labelled sample report used in the site's PDF reader."""
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'public' / 'ATI_Primer_Pravovogo_Analiza.pdf'
OUT.parent.mkdir(exist_ok=True)
FONT = Path('/usr/share/fonts/truetype/dejavu')
pdfmetrics.registerFont(TTFont('DejaVu', str(FONT / 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DejaVuBold', str(FONT / 'DejaVuSans-Bold.ttf')))
W, H = A4
RED = HexColor('#762b38'); GOLD = HexColor('#bd9957'); INK = HexColor('#3f3437')
styles = {
  'body': ParagraphStyle('body', fontName='DejaVu', fontSize=10, leading=16, textColor=INK, alignment=TA_LEFT),
  'heading': ParagraphStyle('heading', fontName='DejaVuBold', fontSize=14, leading=20, textColor=RED),
  'small': ParagraphStyle('small', fontName='DejaVu', fontSize=8, leading=13, textColor=HexColor('#79685d')),
  'title': ParagraphStyle('title', fontName='DejaVuBold', fontSize=25, leading=33, textColor=RED),
}
c = canvas.Canvas(str(OUT), pagesize=A4)
c.setTitle('АТИ - Пример структуры правового анализа')
c.setAuthor('АТИ')

def paragraph(text, y, style='body', x=46, width=W-92):
    p = Paragraph(text, styles[style]); _, h = p.wrap(width, H)
    if y-h < 75: raise RuntimeError('Page content overflow')
    p.drawOn(c, x, y-h)
    return y-h

def frame(number, category):
    c.setFillColor(HexColor('#fffdfa')); c.rect(0, 0, W, H, fill=1, stroke=0)
    c.setFillColor(RED); c.rect(0, H-108, W, 108, fill=1, stroke=0)
    c.setFillColor(HexColor('#ead5ad')); c.setFont('DejaVuBold', 30); c.drawString(46, H-54, 'АТИ')
    c.setFont('DejaVu', 8); c.drawString(47, H-78, 'ПРАВОВОЙ АНАЛИЗ ВОЗМОЖНОСТИ ВЗЫСКАНИЯ')
    c.setStrokeColor(GOLD); c.setLineWidth(2); c.line(0, H-109, W, H-109)
    c.setFillColor(GOLD); c.setFont('DejaVuBold', 8); c.drawString(46, H-142, 'ДЕМОНСТРАЦИОННЫЙ ОБРАЗЕЦ')
    c.setStrokeColor(HexColor('#ded1ba')); c.setLineWidth(.5); c.line(46, 57, W-46, 57)
    c.setFillColor(HexColor('#8c7665')); c.setFont('DejaVu', 7)
    c.drawString(46, 39, 'АТИ  /  Пример структуры отчёта')
    c.drawRightString(W-46, 39, f'{number} / 4')
    return paragraph(category, H-165, 'title')-23

def block(title, body, y):
    y = paragraph(title, y, 'heading')-10
    y = paragraph(body, y)-23
    return y

y = frame(1, 'Резюме и задачи анализа')
y = paragraph('Перед вами пример разделов будущего отчёта. Фактические сведения о должнике и выводы заполняются после проверки документов и источников.', y)-28
y = block('01. Исходная ситуация', 'Кредитор: [наименование]<br/>Должник: [наименование, ИНН]<br/>Основание долга: [договор и подтверждающие документы]<br/>Сумма задолженности: [по документам кредитора]', y)
y = block('02. Главные вопросы', 'Есть ли подтверждённое обязательство? Есть ли имущество и денежные средства для исполнения? Какой способ взыскания соответствует обстоятельствам дела?', y)
y = block('03. Итоговая оценка', 'Возможность и вероятность взыскания, выявленные ограничения, рекомендуемый маршрут и документы для следующего шага.', y)
c.showPage()

y = frame(2, 'Активы и обязательства')
y = block('01. Имущество должника', 'Недвижимость, транспорт и иное имущество. Для каждого обнаруженного актива фиксируются источник, дата проверки, доступные сведения и ограничения.', y)
y = block('02. Счета и ограничения', 'Сведения о блокировках счетов и имеющихся обязательствах. Отдельно отмечаются данные, которые требуют дополнительного подтверждения.', y)
y = block('03. Исполнительные производства', 'Перечень производств, суммы требований, состояние исполнения и сведения об оконченных производствах. Оценка конкуренции с другими взыскателями.', y)
y = block('Состав строки проверки', 'Объект проверки → источник → дата → установленный факт → значение для взыскания → следующий шаг.', y)
c.showPage()

y = frame(3, 'Судебные дела и риски')
y = block('01. Судебные споры', 'Дела с участием должника: предмет спора, цена требований, стадия и результат. Выявление других кредиторов и повторяющихся обстоятельств.', y)
y = block('02. Банкротство и ликвидация', 'Проверка статуса должника, опубликованных сообщений и признаков процедур, влияющих на порядок и сроки предъявления требований.', y)
y = block('03. Правовая позиция', 'Договор, первичные документы, переписка, сроки оплаты, соблюдение претензионного порядка и исковая давность. Перечень недостающих доказательств.', y)
y = block('Карта рисков', 'Каждый риск связывается с подтверждающим источником, возможными последствиями и действием, которое необходимо предпринять.', y)
c.showPage()

y = frame(4, 'Стратегия взыскания')
y = block('01. Рекомендуемый маршрут', 'Досудебная претензия → исковое заявление → судебный процесс → решение → исполнительный документ → исполнение.', y)
y = block('02. Задачи по этапам', 'Для каждого этапа: необходимый комплект документов, ответственное действие, контрольная точка, предполагаемые расходы и условия перехода к следующему шагу.', y)
y = block('03. Требования к должнику', 'Основной долг, неустойка и судебные расходы рассматриваются с учётом представленных документов и обстоятельств дела.', y)
y = block('04. Решение кредитора', 'По результатам анализа выбирается дальнейшее действие: предъявить требования, дополнить доказательства или пересмотреть стратегию взыскания.', y)
c.showPage()
c.save()
print(OUT)
