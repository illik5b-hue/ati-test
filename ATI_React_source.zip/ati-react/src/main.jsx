import React from 'react';
import { createRoot, hydrateRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import { SITE_BASE_PATH } from './site-config.js';
import './style.css';
import './analysis.css';

const legacy = /^#\/(services|analysis|recovery)?\/?$/.exec(window.location.hash);
if (legacy) {
  const target = legacy[1] ? `${legacy[1]}.html` : '';
  window.history.replaceState(null, '', `${SITE_BASE_PATH}/${target}`);
}
const root = document.getElementById('root');
const app = <BrowserRouter basename={SITE_BASE_PATH}><App /></BrowserRouter>;
if (root.hasChildNodes() && !legacy) hydrateRoot(root, app);
else createRoot(root).render(app);
