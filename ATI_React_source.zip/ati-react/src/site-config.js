export const SITE_BASE_PATH = '/ati-test';
export const SITE_URL = 'https://illik5b-hue.github.io/ati-test/';

// Fill these fields with the business's approved information before enabling requests.
export const business = {
  phone: '',
  email: '',
  address: '',
  legalName: '',
  inn: '',
  privacyApproved: false,
  policyText: '',
  consentText: '',
  requestEndpoint: '',
};

export function requestsEnabled() {
  return Boolean(business.privacyApproved && business.legalName && business.policyText &&
    business.consentText && /^https:\/\//.test(business.requestEndpoint));
}

export const assetUrl = (filename) => `${SITE_BASE_PATH}/${filename}`;
export const pageMeta = {
  '/': {
    title: 'АТИ — Взыскание задолженности и убытков для бизнеса',
    description: 'Юридические услуги для юридических лиц и ИП: анализ возможности взыскания за 5 000 ₽ и взыскание долга под ключ 45 000 ₽.',
  },
  '/services.html': {
    title: 'Услуги по взысканию задолженности — АТИ',
    description: 'Два пути решения: правовой анализ возможности взыскания или полный цикл взыскания задолженности для бизнеса.',
  },
  '/analysis.html': {
    title: 'Правовой анализ возможности взыскания — 5 000 ₽ | АТИ',
    description: 'Оценка возможности, способов и вероятности взыскания с точностью до 1 %. Проверка активов, исполнительных производств, судов и банкротства.',
  },
  '/recovery.html': {
    title: 'Взыскание долга под ключ — 45 000 ₽ | АТИ',
    description: 'От досудебной претензии до списания средств со счёта должника: восемь этапов взыскания долга для юридических лиц и ИП.',
  },
  '/privacy.html': { title: 'Политика конфиденциальности — АТИ', description: 'Политика обработки персональных данных АТИ.' },
  '/consent.html': { title: 'Согласие на обработку персональных данных — АТИ', description: 'Согласие на обработку персональных данных.' },
};
