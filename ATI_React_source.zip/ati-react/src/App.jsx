import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Link, NavLink, Route, Routes, useLocation } from 'react-router-dom';
import { ArrowRight, ArrowLeft, Scale, Menu, X, Phone, Mail, MapPin, FileText, Download, Check, ChevronRight } from 'lucide-react';
import { assetUrl, business, requestsEnabled, SITE_URL, pageMeta } from './site-config.js';

const analysisQuestions = [
  'Хотите понять, реально ли взыскать долг и стоит ли тратить на это ресурсы?',
  'Не уверены в платёжеспособности должника?',
  'Юристы говорят общими фразами, а вам нужна конкретика?',
  'Ищете прозрачность и точные цифры вместо «возможно/вероятно»?',
];
const recoveryQuestions = [
  'Должник не возвращает деньги, тянет время и не исполняет обязательства?',
  'Нужен полный цикл: от претензии до списания средств со счёта должника?',
  'Хотите вернуть не только долг, но и все судебные расходы?',
];
const reportItems = [
  'Чёткую оценку возможности, способов и вероятности взыскания (с точностью до 1 %).',
  'Выявление активов должника (недвижимость, транспорт, иное имущество).',
  'Информацию о заблокированных счетах (признак уже имеющихся долгов перед ФНС).',
  'Данные об исполнительных производствах (подтверждение просроченных обязательств).',
  'Аналитику судебных дел с участием должника (кто ещё пытается взыскать с него деньги).',
  'Проверку на банкротство и ликвидацию (чтобы понимать риски и сроки взыскания).',
];
const recoverySteps = [
  'Сбор документов.', 'Направление досудебной претензии.', 'Подача иска.',
  'Судебный процесс.', 'Получение выигрышного решения.',
  'Добровольная оплата должником или получение исполнительного листа.',
  'Передача листа приставам.', 'Списание средств со счёта должника на ваш счёт.',
];

function Action({ children, onClick, outline = false, className = '', ...props }) {
  return <button type="button" className={`btn ${outline ? 'outline' : ''} ${className}`} onClick={onClick} {...props}>{children}<ArrowRight size={17} aria-hidden="true" /></button>;
}
function Brand() {
  return <Link className="brand" to="/" aria-label="АТИ — главная"><span className="brandmark"><Scale size={29} /></span><span><strong>АТИ</strong><small>Взыскание долгов<br />за перевозку</small></span></Link>;
}
function Ticks({ items }) {
  return <ul className="ticks">{items.map(item => <li key={item}><Check size={18} aria-hidden="true" /><span>{item}</span></li>)}</ul>;
}
function ProductCards({ open, full = false }) {
  return <div className="cards">
    <article className="card"><span className="cardnumber">01 / ОЦЕНИТЬ ПЕРСПЕКТИВЫ</span><h2>Анализ возможности взыскания</h2>
      {full ? <ul className="questions">{analysisQuestions.map(q => <li key={q}>{q}</li>)}</ul> : <p>Поймите, реально ли вернуть долг. Получите оценку платёжеспособности должника, точные цифры и стратегию действий.</p>}
      <p className="price">5 000 ₽</p><Action onClick={() => open('Правовой анализ')}>Заказать анализ</Action><Link className="textlink" to="/analysis.html">Подробнее об анализе <ChevronRight size={15} /></Link>
    </article>
    <article className="card"><span className="cardnumber">02 / ВЕРНУТЬ ДЕНЬГИ</span><h2>Взыскание под ключ</h2>
      {full ? <ul className="questions">{recoveryQuestions.map(q => <li key={q}>{q}</li>)}</ul> : <p>Передайте нам весь процесс: от претензии до списания средств со счёта должника. Взыщите долг и судебные расходы.</p>}
      <p className="price">45 000 ₽ <span>+ госпошлина</span></p><Action onClick={() => open('Взыскание под ключ')}>Начать взыскание</Action><Link className="textlink" to="/recovery.html">Подробнее о взыскании <ChevronRight size={15} /></Link>
    </article>
  </div>;
}
function Home({ open }) {
  return <>
    <section className="hero"><div className="wrap heroGrid"><div><p className="eyebrow">Юридическая компания АТИ</p><h1>Взыскание задолженности и убытков: <em>возвращаем ваши деньги</em></h1><p className="lead">Юридические услуги для бизнеса: для юридических лиц и ИП</p><p>Вы потеряли деньги из-за недобросовестного контрагента? Должник тянет время, а юристы не дают чёткой картины? Мы берём на себя весь процесс: от анализа перспектив до фактического возврата средств. Работаем строго по алгоритму, опираемся на данные и цифры — никаких расплывчатых обещаний.</p></div>
      <aside className="heroPanel"><div className="heroPanelInner"><Scale size={52} strokeWidth={1.2} aria-hidden="true" /><span className="heroBrand">АТИ</span><p className="heroTagline">Взыскание долгов<br />за перевозку</p><span className="heroRule" /><h2>Узнать перспективы взыскания</h2><Action onClick={() => open('Правовой анализ')}>Получить анализ</Action></div></aside>
    </div></section>
    <section className="wrap section"><div className="sectionHead"><p className="eyebrow">Ваш долг — наша работа</p><h2>Два пути решения вашей проблемы</h2></div><ProductCards open={open} /></section>
    <section className="band"><div className="wrap bandinner"><div><p className="eyebrow">Первый шаг к результату</p><h2>Узнать перспективы взыскания</h2></div><Action onClick={() => open('Правовой анализ')}>Получить анализ</Action></div></section>
  </>;
}
function Services({ open }) {
  return <><section className="wrap section page"><p className="eyebrow">Услуги для бизнеса</p><h1>Два пути решения вашей проблемы</h1><p className="lead">Начните с оценки перспектив или передайте нам весь процесс взыскания.</p><ProductCards open={open} full /></section>
    <section className="darkBand"><div className="wrap bandinner"><div><p className="eyebrow">Решение за вами</p><h2>Выберите подходящий вариант</h2></div><div className="actions"><Action outline onClick={() => open('Правовой анализ')}>Заказать анализ</Action><Action outline onClick={() => open('Взыскание под ключ')}>Начать взыскание</Action></div></div></section>
  </>;
}
const reportPages = ['Резюме и задачи анализа', 'Активы и обязательства', 'Судебные дела и риски', 'Стратегия взыскания'];
function ReportViewer() {
  const [page, setPage] = useState(0);
  const pdf = assetUrl('ATI_Primer_Pravovogo_Analiza.pdf');
  return <aside className="report" aria-label="Пример отчёта правового анализа"><div className="reportTop"><span><FileText size={17} aria-hidden="true" /> ПРИМЕР ОТЧЁТА</span><span>PDF · 4 страницы</span></div>
    <a className="reportImage" href={`${pdf}#page=${page + 1}`} target="_blank" rel="noreferrer" aria-label={`Открыть PDF: страница ${page + 1}, ${reportPages[page]}`}><img src={assetUrl(`report-page-${page + 1}.jpg`)} width="794" height="1123" alt={`Демонстрационный отчёт. Страница ${page + 1}: ${reportPages[page]}`} /></a>
    <div className="reportControls"><button type="button" disabled={page === 0} onClick={() => setPage(p => p - 1)} aria-label="Предыдущая страница отчёта"><ArrowLeft size={18} /></button><span aria-live="polite">{page + 1} / {reportPages.length}</span><button type="button" disabled={page === reportPages.length - 1} onClick={() => setPage(p => p + 1)} aria-label="Следующая страница отчёта"><ArrowRight size={18} /></button></div>
    <p className="reportCaption">Демонстрационный образец структуры отчёта</p><a className="downloadLink" href={pdf} download="ATI_Primer_Pravovogo_Analiza.pdf"><Download size={16} aria-hidden="true" /> Скачать отчёт PDF</a>
  </aside>;
}
function Analysis({ open }) {
  return <section className="wrap section page"><p className="eyebrow">Перспективы в цифрах</p><h1>Правовой анализ: точные цифры и понятная стратегия</h1><p className="price pageprice">Стоимость — 5 000 ₽</p><div className="split"><div><h2>Зачем это нужно?</h2><Ticks items={['Чтобы понять реальную платёжеспособность должника.', 'Чтобы принять решение: идти в суд или прекратить тратить время и деньги.', 'Чтобы получить готовую стратегию действий и не гадать, какие шаги предпринять.']} /><h2>Что вы получите в отчёте?</h2><Ticks items={reportItems} /><div className="analysisCta"><Action onClick={() => open('Правовой анализ')}>Заказать правовой анализ</Action></div></div><ReportViewer /></div></section>;
}
function Recovery({ open }) {
  return <><section className="wrap section page"><p className="eyebrow">Полное сопровождение</p><h1>Взыскание долга под ключ: от иска до списания средств</h1><p className="price pageprice">Стоимость — 45 000 ₽ <span>+ госпошлина</span></p><h2 className="subheading">Восемь этапов к возврату долга</h2><ol className="steps">{recoverySteps.map((step, i) => <li className="step" key={step}><span>{String(i + 1).padStart(2, '0')}</span><p>{step}</p></li>)}</ol>
    <section className="stage"><p className="eyebrow">Подключимся на любом этапе</p><h2>А на какой стадии сейчас вы?</h2><div className="stageGrid"><article><h3>Не знаете, с чего начать?</h3><Link to="/analysis.html">Начните с правового анализа <ArrowRight size={17} /></Link></article><article><h3>Уже есть решение суда?</h3><button type="button" onClick={() => open('Исполнительное производство')}>Поможем с исполнительным производством <ArrowRight size={17} /></button></article><article><h3>Должник тянет время?</h3><button type="button" onClick={() => open('Взыскание под ключ')}>Возьмём на себя все этапы <ArrowRight size={17} /></button></article></div></section>
    <section className="why"><h2>Почему мы?</h2><Ticks items={['Смотрим на ситуацию шире: анализируем должника со всех сторон.', 'Помогаем взыскать все судебные расходы: вы вернёте не только долг и неустойку, но и деньги за наши услуги, госпошлину и почтовые расходы.', 'Работаем по прозрачному алгоритму и даём понятные отчёты на каждом этапе.']} /></section></section>
    <section className="darkBand recoveryBand"><div className="wrap bandinner"><div><p className="eyebrow">От документов до возврата денег</p><h2>Доверьте взыскание нам</h2></div><Action outline onClick={() => open('Взыскание под ключ')}>Начать взыскание под ключ</Action></div></section></>;
}
function LegalPage({ consent = false }) {
  const title = consent ? 'Согласие на обработку персональных данных' : 'Политика конфиденциальности';
  const text = consent ? business.consentText : business.policyText;
  return <section className="wrap section page legal"><p className="eyebrow">Документы</p><h1>{title}</h1>{business.privacyApproved && text ? <div className="legalText">{text}</div> : <p className="lead">Документ готовится к публикации. Приём заявок будет доступен после размещения документов.</p>}<Link className="textlink" to="/">Вернуться на главную <ArrowRight size={16} /></Link></section>;
}
function ContactDetails({ compact = false }) {
  return <div className={compact ? 'headerContacts' : 'contactDetails'}>
    {business.phone && <a href={`tel:${business.phone.replace(/[^+\d]/g, '')}`}><Phone size={16} aria-hidden="true" />{business.phone}</a>}
    {business.email && <a href={`mailto:${business.email}`}><Mail size={16} aria-hidden="true" />{business.email}</a>}
    {!compact && business.address && <p><MapPin size={16} aria-hidden="true" />{business.address}</p>}
    {compact && !business.phone && !business.email && <a href="#contacts">Контакты <ArrowRight size={14} aria-hidden="true" /></a>}
    {!compact && !business.phone && !business.email && <p>Контактные данные готовятся к публикации.</p>}
  </div>;
}
function Footer({ open }) {
  return <footer id="contacts"><div className="wrap foot"><div><span className="footlogo">АТИ</span><p className="footTagline">Взыскание долгов за перевозку</p><p>Юридические услуги для бизнеса.<br />Взыскание задолженности и убытков.</p></div><div><h2>Контакты</h2><ContactDetails /><button type="button" className="footlink" onClick={() => open('Консультация')}>Оставить заявку <ArrowRight size={15} /></button></div><div><h2>Документы</h2><Link to="/privacy.html">Политика конфиденциальности</Link><Link to="/consent.html">Согласие на обработку данных</Link>{business.legalName && <p>{business.legalName}{business.inn ? ` · ИНН ${business.inn}` : ''}</p>}</div></div><div className="wrap footbottom">© АТИ · Юридические услуги для юридических лиц и ИП</div></footer>;
}
function RequestDialog({ service, close }) {
  const dialog = useRef(null);
  const [status, setStatus] = useState('idle');
  const enabled = requestsEnabled();
  useEffect(() => {
    const prior = document.activeElement;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    dialog.current?.focus();
    function keydown(event) {
      if (event.key === 'Escape') close();
      if (event.key !== 'Tab') return;
      const items = [...dialog.current.querySelectorAll('a[href], button:not(:disabled), input:not(:disabled), textarea:not(:disabled)')].filter(el => !el.closest('fieldset:disabled'));
      const first = items[0], last = items[items.length - 1];
      if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog.current)) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || document.activeElement === dialog.current)) { event.preventDefault(); first?.focus(); }
    }
    document.addEventListener('keydown', keydown);
    return () => { document.removeEventListener('keydown', keydown); document.body.style.overflow = overflow; prior?.focus(); };
  }, [close]);
  async function submit(event) {
    event.preventDefault();
    if (!enabled || status === 'sending') return;
    const data = new FormData(event.currentTarget);
    if (!data.get('consent') || !data.get('policy')) return;
    setStatus('sending');
    try {
      const response = await fetch(business.requestEndpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ service, name: data.get('name'), phone: data.get('phone'), details: data.get('details'), consent: true, policy: true, consentVersion: '1' }), signal: AbortSignal.timeout(15000) });
      const result = await response.json();
      if (!response.ok || result.ok !== true) throw new Error('Request not accepted');
      setStatus('sent');
    } catch { setStatus('error'); }
  }
  return <div className="overlay" onClick={e => { if (e.target === e.currentTarget) close(); }}><section className="dialog" ref={dialog} role="dialog" aria-modal="true" aria-labelledby="request-title" aria-describedby="request-service" tabIndex={-1}>
    <button type="button" className="close" onClick={close} aria-label="Закрыть форму"><X size={23} /></button><p className="eyebrow">Обсудим вашу задачу</p><h2 id="request-title">Оставить заявку</h2><p id="request-service" className="serviceName">{service}</p>
    {status === 'sent' ? <div role="status"><h3>Заявка принята</h3><p>Мы свяжемся с вами по указанному номеру.</p><Action onClick={close}>Закрыть</Action></div> : <>
      {!enabled && <div className="formNotice" role="status">Приём заявок пока не подключён.</div>}
      <form onSubmit={submit}><fieldset disabled={!enabled || status === 'sending'}><label htmlFor="request-name">Ваше имя<input id="request-name" name="name" autoComplete="name" required maxLength={100} /></label><label htmlFor="request-phone">Телефон<input id="request-phone" name="phone" type="tel" autoComplete="tel" required maxLength={30} /></label><label htmlFor="request-details">Кратко о вашей ситуации<textarea id="request-details" name="details" rows={3} maxLength={3000} /></label></fieldset>
        <label className="consent"><input type="checkbox" name="consent" required disabled={!enabled || status === 'sending'} /><span>Даю <Link to="/consent.html" target="_blank" rel="noreferrer">согласие на обработку персональных данных</Link></span></label>
        <label className="consent"><input type="checkbox" name="policy" required disabled={!enabled || status === 'sending'} /><span>Я ознакомился с <Link to="/privacy.html" target="_blank" rel="noreferrer">политикой конфиденциальности</Link></span></label>
        {status === 'error' && <p role="alert" className="formError">Заявка не отправлена. Попробуйте ещё раз.</p>}
        <button className="btn" type="submit" disabled={!enabled || status === 'sending'}>{status === 'sending' ? 'Отправляем…' : 'Отправить заявку'}<ArrowRight size={17} aria-hidden="true" /></button>
      </form></>}
  </section></div>;
}
export default function App() {
  const [menu, setMenu] = useState(false);
  const [service, setService] = useState('');
  const location = useLocation();
  const close = useCallback(() => setService(''), []);
  useEffect(() => {
    setMenu(false);
    const path = location.pathname === '/index.html' ? '/' : location.pathname;
    const meta = pageMeta[path];
    if (meta) {
      document.title = meta.title;
      document.querySelector('meta[name="description"]')?.setAttribute('content', meta.description);
      document.querySelector('link[rel="canonical"]')?.setAttribute('href', SITE_URL + (path === '/' ? '' : path.slice(1)));
    }
    const noindex = !meta || (['/privacy.html', '/consent.html'].includes(path) && !business.privacyApproved);
    document.querySelector('meta[name="robots"]')?.setAttribute('content', noindex ? 'noindex, follow' : 'index, follow');
    if (!location.hash) window.scrollTo(0, 0);
  }, [location.pathname]);
  return <><a className="skipLink" href="#main">Перейти к содержимому</a><header><div className="wrap head"><Brand /><nav className={menu ? 'open' : ''} aria-label="Основная навигация"><NavLink to="/" end>Главная</NavLink><NavLink to="/services.html">Услуги</NavLink><NavLink to="/analysis.html">Правовой анализ</NavLink><NavLink to="/recovery.html">Взыскание под ключ</NavLink></nav><ContactDetails compact /><button type="button" className="mobile" aria-label={menu ? 'Закрыть меню' : 'Открыть меню'} aria-expanded={menu} onClick={() => setMenu(v => !v)}>{menu ? <X /> : <Menu />}</button></div></header>
    <main id="main"><Routes><Route path="/" element={<Home open={setService} />} /><Route path="/index.html" element={<Home open={setService} />} /><Route path="/services.html" element={<Services open={setService} />} /><Route path="/analysis.html" element={<Analysis open={setService} />} /><Route path="/recovery.html" element={<Recovery open={setService} />} /><Route path="/privacy.html" element={<LegalPage />} /><Route path="/consent.html" element={<LegalPage consent />} /><Route path="*" element={<section className="wrap section page"><h1>Страница не найдена</h1><Link className="textlink" to="/">На главную <ArrowRight size={16} /></Link></section>} /></Routes></main>
    <Footer open={setService} />{service && <RequestDialog key={service} service={service} close={close} />}</>;
}
